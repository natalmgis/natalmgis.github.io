define({
  "_widgetLabel": "Controlador de capçalera",
  "signin": "Inicia la sessió",
  "signout": "Tanca la sessió",
  "about": "Quant a",
  "signInTo": "Inicia la sessió al",
  "cantSignOutTip": "Aquesta funció no està disponible en el mode de visualització prèvia.",
  "more": "més"
});