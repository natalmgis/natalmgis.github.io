define({
  "_widgetLabel": "Controlador do Cabeçalho",
  "signin": "Entrar",
  "signout": "Sair",
  "about": "Sobre",
  "signInTo": "Entrar no",
  "cantSignOutTip": "Esta função é N/A no modo de visualização.",
  "more": "mais"
});