define({
  "_themeLabel": "Foldable-Design",
  "_layout_default": "Standard-Layout",
  "_layout_layout1": "Layout 1"
});